"""Scientific regression tests, using unittest (no extra test dependency)."""
import unittest
from dataclasses import replace
import numpy as np
from active_engine import Parameters,Engine,solve,matrices,kalman_update
from active_engine.model import van_loan
from active_engine.validate import direct_work,forward_gradient,finite_difference

class TestPhysics(unittest.TestCase):
    def test_equal_relaxation_times_and_integral_discretization(self):
        for tau in [.05,.5,1.,1.+1e-10,10.]:
            p=Parameters(tau=tau,Da=4*tau)
            F,Q,_,S=matrices(p);Fi,Qi=van_loan(p)
            np.testing.assert_allclose(F,Fi,rtol=1e-12,atol=1e-13)
            np.testing.assert_allclose(Q,Qi,rtol=1e-11,atol=1e-12)
            self.assertGreater(np.linalg.eigvalsh(Q)[0],0.)
            np.testing.assert_allclose(S,F@S@F.T+Q,atol=1e-13)
    def test_zero_precision_omits_observation(self):
        mean=np.array([1.,2.]);cov=np.array([[2.,.5],[.5,3.]])
        m,s=kalman_update(mean,cov,0.,observation=np.nan)
        np.testing.assert_array_equal(m,mean);np.testing.assert_array_equal(s,cov)
        m,s=kalman_update(mean,cov,2.,3.)
        self.assertNotEqual(m[1],mean[1]);self.assertLess(s[1,1],cov[1,1])
    def test_periodic_closure_is_not_reset(self):
        e=Engine(Parameters());r=np.full(50,.2);r[-1]=3.
        o=e.filter(r)
        np.testing.assert_allclose(o['minus'][0],e.F@o['plus'][-1]@e.F.T+e.Q,atol=2e-12)
        self.assertGreater(np.max(abs(o['minus'][0]-e.stationary)),.1)
        np.testing.assert_array_equal(e.W[-1],np.zeros((2,2)))
    def test_adjoint_forward_sensitivity_and_finite_difference(self):
        for p in [Parameters(N=12),Parameters(N=12,passive=True,Da=0)]:
            e=Engine(p);r=np.linspace(.03,.8,p.N);g=e.evaluate(r)['gradient']
            np.testing.assert_allclose(g,forward_gradient(e,r),atol=2e-12)
            np.testing.assert_allclose(g,finite_difference(e,r),atol=2e-8)
    def test_direct_work_and_full_information(self):
        for p in [Parameters(N=12),Parameters(N=12,passive=True,Da=0)]:
            e=Engine(p);r=np.linspace(0.,.5,p.N)
            o=e.evaluate(r);d=direct_work(e,r);f=direct_work(e,r,True)
            self.assertLess(abs(d['work']-o['J_mech']),2e-11)
            self.assertLess(abs(f['work']-e.full_information_work),2e-11)
            self.assertLess(d['cycle_radius'],1.)
            np.testing.assert_allclose(o['J_net'],o['J_mech']-o['C_sens'])
    def test_concavity_on_feasible_schedules(self):
        e=Engine(Parameters(N=12));rng=np.random.default_rng(11)
        for _ in range(6):
            a=rng.uniform(0,3,e.N);b=rng.uniform(0,3,e.N);alpha=.37
            ja=e.evaluate(a)['J_net'];jb=e.evaluate(b)['J_net']
            middle=e.evaluate(alpha*a+(1-alpha)*b)['J_net']
            self.assertGreaterEqual(middle+1e-12,alpha*ja+(1-alpha)*jb)
    def test_active_and_passive_optimized_reference(self):
        e=Engine(Parameters());o=solve(e,polish=True)
        self.assertAlmostEqual(o['J_net'],2.229314356,places=8)
        self.assertAlmostEqual(o['marginal'][-1],.0874644670,places=8)
        self.assertEqual(o['rho'][-1],0.)
        p=solve(Engine(Parameters(passive=True,Da=0)),polish=True)
        self.assertAlmostEqual(p['J_net'],.528038046,places=8)
        self.assertEqual(p['rho'][-1],0.)
    def test_nonzero_closing_sensing_is_cross_cycle(self):
        e=Engine(Parameters(price=.001));o=solve(e,polish=True)
        self.assertAlmostEqual(o['rho'][-1],.0405023738,places=7)
        t=e.temporal(o['rho']);last=t[-1]
        self.assertEqual(last['immediate'],0.);self.assertEqual(last['intra'],0.)
        self.assertAlmostEqual(last['cross'],.001,places=11)
        self.assertLess(max(x['series_error'] for x in t),1e-11)
    def test_passive_transfer_and_active_ordering_failure(self):
        r=np.full(50,2.);r[-1]=3.;t=r.copy();t[0]+=t[-1];t[-1]=0.
        e=Engine(Parameters(passive=True,Da=0))
        self.assertGreaterEqual(e.evaluate(t)['J_mech']+1e-12,e.evaluate(r)['J_mech'])
        # At the active optimum, removing its positive closing precision loses work.
        a=Engine(Parameters(price=.001));o=solve(a,polish=True);t=o['rho'].copy();t[0]+=t[-1];t[-1]=0.
        self.assertLess(a.evaluate(t)['J_net'],o['J_net'])
    def test_invalid_input_and_no_sensing(self):
        with self.assertRaises(ValueError):Parameters(N=1)
        with self.assertRaises(ValueError):Parameters(price=0)
        e=Engine(Parameters(N=5))
        for r in [np.ones(4),np.r_[-1.,np.ones(4)],np.full(5,np.nan)]:
            with self.assertRaises(ValueError):e.evaluate(r)
        self.assertAlmostEqual(e.evaluate(np.zeros(5))['J_net'],0.,places=11)

if __name__=='__main__':unittest.main()
