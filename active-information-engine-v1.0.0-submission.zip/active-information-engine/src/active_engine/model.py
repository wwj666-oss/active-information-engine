"""Exact sampled AOUP and scalar thermal reference; SM I, VI C."""
from dataclasses import dataclass
import numpy as np
from scipy.linalg import expm

@dataclass(frozen=True)
class Parameters:
    kBT: float = 1.
    gamma: float = 1.
    kappa: float = 1.
    dt: float = .1
    N: int = 50
    tau: float = .5
    Da: float = 2.
    price: float = .1
    passive: bool = False

    def __post_init__(self):
        if not isinstance(self.N, (int, np.integer)) or self.N < 2:
            raise ValueError('N must be an integer >= 2')
        vals = [self.kBT, self.gamma, self.kappa, self.dt, self.tau, self.price]
        if not np.all(np.isfinite(vals)) or min(vals) <= 0:
            raise ValueError('Thermal, time and price parameters must be finite and positive')
        if not np.isfinite(self.Da) or (self.Da <= 0 and not self.passive):
            raise ValueError('Active noise strength must be positive')

    @property
    def duration(self):
        return self.N * self.dt


def matrices(p):
    rate = p.kappa / p.gamma
    r = np.exp(-rate*p.dt)
    if p.passive:
        F = np.array([[r]])
        S = np.array([[p.kBT/p.kappa]])
        b = np.array([1-r])
    else:
        decay = 1/p.tau
        a = np.exp(-decay*p.dt)
        # expm1 retains accuracy at tau == gamma/kappa and nearby.
        delta = (rate-decay)*p.dt
        coupling = (r*p.dt/p.gamma if delta == 0 else
                    (np.exp(-decay*p.dt)-r)/((rate-decay)*p.gamma))
        if abs(delta) < 1e-4:
            coupling = r*p.dt/p.gamma * (np.expm1(delta)/delta if delta else 1.)
        F = np.array([[r,coupling],[0.,a]])
        cross = p.Da/(p.gamma+p.kappa*p.tau)
        S = np.array([[p.kBT/p.kappa+cross/p.kappa,cross],
                      [cross,p.Da/p.tau]])
        b = np.array([1-r,0.])
    Q = S-F@S@F.T
    Q = (Q+Q.T)/2
    if np.linalg.eigvalsh(Q)[0] <= 0:
        raise ArithmeticError('Discrete noise covariance lost positivity')
    return F,Q,b,S


def kalman_update(mean, covariance, precision, observation=None):
    """At precision zero no observation is requested or inspected (SM S5-S7)."""
    if not np.isfinite(precision) or precision < 0:
        raise ValueError('precision must be finite and nonnegative')
    if precision == 0:
        return np.array(mean,copy=True),np.array(covariance,copy=True)
    if observation is None or not np.isfinite(observation):
        raise ValueError('A finite observation is required at positive precision')
    d = covariance[:,0]
    L = precision*d/(1+precision*covariance[0,0])
    return mean+L*(observation-mean[0]), covariance-np.outer(L,d)


def van_loan(p):
    """Independent integral discretization, for validation at moderate dt/tau."""
    if p.passive:
        A=np.array([[-p.kappa/p.gamma]])
        G=np.array([[2*p.kBT/p.gamma]])
    else:
        A=np.array([[-p.kappa/p.gamma,1/p.gamma],[0.,-1/p.tau]])
        G=np.diag([2*p.kBT/p.gamma,2*p.Da/p.tau**2])
    n=len(A);V=np.zeros((2*n,2*n));V[:n,:n]=A;V[:n,n:]=G;V[n:,n:]=-A.T
    E=expm(V*p.dt);F=E[:n,:n];Q=E[:n,n:]@F.T
    return F,(Q+Q.T)/2
