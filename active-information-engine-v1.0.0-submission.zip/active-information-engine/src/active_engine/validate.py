"""Checks independent of the reduced-work and cyclic-adjoint evaluations."""
import numpy as np
from scipy.linalg import solve_discrete_lyapunov
from .model import van_loan


def _stationary_work(transitions,noises,jumps,kappa,n):
    dim=len(transitions[0]);cycle=np.eye(dim);noise=np.zeros((dim,dim))
    for A,Q in zip(transitions,noises):
        cycle=A@cycle;noise=A@noise@A.T+Q
    radius=float(max(abs(np.linalg.eigvals(cycle))))
    if radius>=1:raise ArithmeticError('Independent closed-loop covariance is unstable')
    covariance=solve_discrete_lyapunov(cycle,noise);start=covariance.copy()
    relative=np.zeros(dim);relative[0]=1;relative[-1]=-1
    work=0.;minimum=float(np.linalg.eigvalsh(covariance)[0])
    for A,Q,(M,V,T) in zip(transitions,noises,jumps):
        posterior=M@covariance@M.T+V
        after=T@posterior@T.T
        work+=.5*kappa*(relative@posterior@relative-relative@after@relative)
        covariance=A@covariance@A.T+Q
        minimum=min(minimum,float(np.linalg.eigvalsh(covariance)[0]))
    return dict(work=float(work),cycle_radius=radius,
                moment_residual=float(np.max(abs(covariance-start))),
                lyapunov_residual=float(np.max(abs(start-cycle@start@cycle.T-noise))),
                minimum_augmented_eigenvalue=minimum)


def direct_work(engine,rho,full_information=False):
    """Stationary physical-state/estimate/trap covariance and energy jumps.

    This path never calls Engine.evaluate, W, the reduced identity or the adjoint.
    The actual x,f and estimated x,f remain separate stochastic coordinates.
    """
    n=engine.n;p=engine.p;F,Q,b=engine.F,engine.Q,engine.b
    dim=n+1 if full_information else 2*n+1
    dynamics=np.zeros((dim,dim));dynamics[:n,:n]=F;dynamics[:n,-1]=b
    dynamics[-1,-1]=1.;noise=np.zeros((dim,dim));noise[:n,:n]=Q
    if not full_information:
        dynamics[n:2*n,n:2*n]=F;dynamics[n:2*n,-1]=b
        orbit=engine.filter(rho)
    transitions=[];noises=[];jumps=[]
    for k in range(engine.N):
        M=np.eye(dim);V=np.zeros((dim,dim));T=np.eye(dim)
        if not full_information:
            prior=orbit['minus'][k]
            L=rho[k]*prior[:,0]/(1+rho[k]*prior[0,0])
            M[n:2*n,0]+=L;M[n:2*n,n]-=L
            if rho[k]>0:V[n:2*n,n:2*n]=np.outer(L,L)/rho[k]
        if k==engine.N-1:T[-1,:]=0.
        elif full_information:T[-1,:]+=engine.gain[k]
        else:T[-1,n:]+=engine.gain[k]
        transitions.append(dynamics@T@M)
        noises.append(dynamics@T@V@T.T@dynamics.T+noise)
        jumps.append((M,V,T))
    return _stationary_work(transitions,noises,jumps,p.kappa,n)


def forward_gradient(engine,rho):
    """Forward covariance sensitivities with an independently closed tangent orbit."""
    o=engine.filter(rho);F=engine.F;U=o['U'];A=o['A'];n=engine.n;N=engine.N
    grads=np.empty(N)
    for j in range(N):
        tangent=np.zeros((n,n))
        for k in range(N):
            d=o['plus'][k,:,0]
            tangent=A[k]@tangent@A[k].T
            if k==j:tangent-=F@np.outer(d,d)@F.T
        tangent=solve_discrete_lyapunov(o['cycle'],tangent)
        derivative=0.
        for k in range(N):
            post=U[k]@tangent@U[k].T
            if k==j:
                d=o['plus'][k,:,0];post-=np.outer(d,d)
            derivative+=np.trace(engine.W[k]@post)
            tangent=F@post@F.T
        grads[j]=engine.p.price+derivative
    return grads


def finite_difference(engine,rho,step=1e-5):
    """All components; centered stencil in the interior, forward stencil on a face."""
    r=np.asarray(rho,float);out=np.empty(len(r));eye=np.eye(len(r))
    def f(x):return -engine.evaluate(x)['J_net']
    for j in range(len(r)):
        h=step*max(1.,abs(r[j]))
        if r[j]>=h:out[j]=(f(r+h*eye[j])-f(r-h*eye[j]))/(2*h)
        else:out[j]=(-3*f(r)+4*f(r+h*eye[j])-f(r+2*h*eye[j]))/(2*h)
    return out


def diagnostics(engine,result,check_gradient=True):
    r=result['rho'];o=engine.evaluate(r);direct=direct_work(engine,r)
    full=direct_work(engine,r,full_information=True)
    F,Q=van_loan(engine.p)
    # A global upper gap bound from concavity and c*||rho*||_1 <= J_FO-J(0).
    at_zero=engine.evaluate(np.zeros(engine.N))['J_net']
    budget=max(0.,(engine.full_information_work-at_zero)/engine.p.price)
    benefit=-o['gradient']
    gap=max(0.,max(0.,float(max(benefit)))*budget-float(benefit@r))
    report=dict(control_residual=engine.control_residual,
                kalman_residual=o['orbit']['residual'],adjoint_residual=o['adjoint_residual'],
                work_absolute_error=abs(direct['work']-o['J_mech']),
                full_information_absolute_error=abs(full['work']-engine.full_information_work),
                discretization_F_error=float(np.max(abs(F-engine.F))),
                discretization_Q_error=float(np.max(abs(Q-engine.Q))),
                posterior_minimum_eigenvalue=float(np.min(np.linalg.eigvalsh(o['orbit']['plus']))),
                curvature_min=float(min(engine.curvature)),
                curvature_lower_bound=engine.p.kappa*(-np.expm1(-2*engine.p.kappa/engine.p.gamma*engine.p.dt)),
                global_net_work_gap_upper_bound=gap,**direct)
    if check_gradient:
        interior=np.full(engine.N,.2)
        analytical=engine.evaluate(interior)['gradient']
        report['finite_difference_max_error']=float(max(abs(finite_difference(engine,interior)-analytical)))
        report['forward_sensitivity_max_error']=float(max(abs(forward_gradient(engine,interior)-analytical)))
    return report
