"""Joint precision optimization with cyclic gradient and KKT acceptance."""
import numpy as np
from scipy.optimize import minimize,root,brentq,minimize_scalar
from dataclasses import replace
from .periodic import Engine
from .model import Parameters


def kkt(rho,gradient):
    return float(np.max(np.where(rho>1e-7,abs(gradient),np.maximum(-gradient,0.))))


def solve(engine,price=None,starts=None,face=False,polish=False):
    c=engine.p.price if price is None else float(price)
    if not np.isfinite(c) or c<=0:raise ValueError('A positive price is required')
    n=engine.N-int(face);scale=np.sqrt(c)
    def unpack(q):
        r=q/scale
        return np.r_[r,0.] if face else r
    def objective(q):
        o=engine.evaluate(unpack(q),c)
        return (o['loss']+o['C_sens'])/scale,o['gradient'][:n]/c
    if starts is None:starts=[np.zeros(engine.N),np.full(engine.N,.15)]
    outcomes=[]
    for seed in starts:
        x=np.broadcast_to(seed,(engine.N,))[:n].copy()*scale
        if np.any(x<0):raise ValueError('Negative starting precision')
        res=minimize(objective,x,jac=True,method='L-BFGS-B',bounds=[(0.,None)]*n,
                     options=dict(ftol=2e-15,gtol=2e-9,maxiter=1500,maxls=40,maxcor=20))
        r=unpack(res.x);o=engine.evaluate(r,c);err=kkt(r[:n],o['gradient'][:n])
        if polish or err>max(2e-9,c*2e-6):
            ix=np.flatnonzero(r[:n]>1e-7)
            def free_gradient(x):
                q=np.zeros(n);q[ix]=x
                return objective(q)[1][ix]
            if len(ix):
                rr=root(free_gradient,res.x[ix],tol=1e-9)
                if np.all(np.isfinite(rr.x)) and np.min(rr.x)>0:
                    q=np.zeros(n);q[ix]=rr.x
                    trial=engine.evaluate(unpack(q),c)
                    if kkt(trial['rho'][:n],trial['gradient'][:n])<err:
                        o=trial;r=o['rho'];err=kkt(r[:n],o['gradient'][:n])
        o.update(kkt=err,optimizer_success=bool(res.success),optimizer_message=str(res.message),
                 face=face,iterations=int(res.nit))
        outcomes.append(o)
    best=max(outcomes,key=lambda o:o['J_net'])
    best['multistart_net_gap']=max(o['J_net'] for o in outcomes)-min(o['J_net'] for o in outcomes)
    best['accepted']=bool(best['kkt']<=max(2e-8,c*2e-5))
    if not best['accepted']:
        raise ArithmeticError(f"Precision KKT check failed: {best['kkt']}, price={c}")
    return best


def activation(tau=.5,guess=1.08146e-3,N=50):
    engine=Engine(Parameters(tau=float(tau),Da=4*float(tau),N=int(N)))
    cache={}
    def value(logc):
        c=float(np.exp(logc))
        if logc not in cache:
            starts=None if not cache else [cache[min(cache,key=lambda x:abs(x-logc))]['rho']]
            cache[logc]=solve(engine,c,starts=starts,face=True,polish=True)
        return -cache[logc]['gradient'][-1]/c
    lo=np.log(guess)-.7;hi=np.log(guess)+.7
    for _ in range(16):
        a=value(lo);b=value(hi)
        if a*b<0:break
        lo-=1.;hi+=1.
    else:raise ArithmeticError('Could not bracket activation')
    x=brentq(value,lo,hi,xtol=2e-9);c=float(np.exp(x));v=value(x)
    return dict(tau=float(tau),c_cross=c,relative_root_residual=abs(v),
                face_kkt=cache[x]['kkt'],g_below=value(x+np.log(.99)),
                g_above=value(x+np.log(1.01)))


def persistence_peak(N=50):
    cache={}
    def evaluate(logtau):
        tau=float(np.exp(logtau))
        if tau not in cache:
            starts=None if not cache else [cache[min(cache,key=lambda x:abs(np.log(x/tau)))]['rho']]
            cache[tau]=solve(Engine(Parameters(N=int(N),tau=tau,Da=4*tau)),starts=starts)
        return cache[tau]
    res=minimize_scalar(lambda x:-evaluate(x)['J_net'],bounds=np.log([.3,3.]),
                        method='bounded',options=dict(xatol=2e-7))
    tau=float(np.exp(res.x));o=evaluate(res.x)
    return dict(N=int(N),T=N*.1,tau_star=tau,J_net=o['J_net'],rho_N=float(o['rho'][-1]),kkt=o['kkt'])
