"""Numerical implementation of the periodic active information engine."""
from .model import Parameters, matrices, kalman_update
from .periodic import Engine
from .optimize import solve, activation, persistence_peak, kkt
