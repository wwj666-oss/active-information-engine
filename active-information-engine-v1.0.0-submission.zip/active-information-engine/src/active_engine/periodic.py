"""Stabilizing periodic control, filter and cyclic adjoint (SM II-IV)."""
import numpy as np
from scipy.linalg import solve_discrete_lyapunov
from scipy.optimize import root
from .model import matrices


def sym(a):
    return (a+a.T)/2


def symmetric_root(mapping, initial, tolerance=2e-11):
    n=len(initial);ix=np.triu_indices(n)
    def unpack(v):
        a=np.zeros((n,n));a[ix]=v
        return a+a.T-np.diag(np.diag(a))
    res=root(lambda v:(mapping(unpack(v))-unpack(v))[ix],initial[ix],tol=1e-11)
    a=unpack(res.x)
    if not np.all(np.isfinite(a)) or np.max(np.abs(mapping(a)-a)) > tolerance:
        raise ArithmeticError('Periodic fixed point failed')
    return a


class Engine:
    def __init__(self, parameters):
        self.p=parameters
        self.F,self.Q,self.b,self.stationary=matrices(parameters)
        self.n=len(self.F);self.N=parameters.N
        self._control()

    def _control(self):
        p=self.p;n=self.n;F=self.F;b=self.b
        A=np.zeros((n+1,n+1));A[:n,:n]=F;A[:n,n]=b;A[n,n]=1
        B=np.r_[b,1.];h=np.r_[1.,np.zeros(n-1),-1.]
        R=np.zeros_like(A);R[:n,:n]=F
        close=np.zeros_like(A);close[0,n]=close[n,0]=-p.kappa;close[n,n]=p.kappa
        def sweep(first,details=False):
            P=close+R.T@first@R
            Ps=[P.copy()];Ks=[];Hs=[];Ws=[]
            for _ in range(self.N-1):
                H=float(p.kappa-B@P@B)
                if H <= 0:
                    raise ArithmeticError('Nonpositive Bellman action curvature')
                a=p.kappa*h+A.T@P@B
                Ks.append(a/H);Hs.append(H);Ws.append(np.outer(a[:n],a[:n])/(2*H))
                P=sym(A.T@P@A+np.outer(a,a)/H);Ps.append(P.copy())
            if details:
                return np.array(Ps[::-1]),np.array(Ks[::-1]),np.array(Hs[::-1]),np.array(Ws[::-1])
            return P
        P=np.zeros_like(A)
        for _ in range(30):
            P=sweep(P)
        P=symmetric_root(sweep,P)
        self.P,self.gain,self.curvature,W=sweep(P,True)
        self.W=np.concatenate([W,np.zeros((1,n,n))])
        self.control_residual=float(np.max(abs(sweep(P)-P)))
        self.full_information_work=float(.5*np.einsum('kij,ji->',self.P[:,:n,:n],self.Q))
        self.control_cycle=np.eye(n+1)
        for k in range(self.N):
            T=np.eye(n+1)
            if k == self.N-1:T[-1,:]=0.
            else:T[-1,:]+=self.gain[k]
            self.control_cycle=A@T@self.control_cycle
        if max(abs(np.linalg.eigvals(self.control_cycle))) >= 1:
            raise ArithmeticError('Riccati solution is not stabilizing')

    def _rho(self,rho):
        r=np.asarray(rho,dtype=float)
        if r.shape != (self.N,) or np.any(~np.isfinite(r)) or np.min(r) < 0:
            raise ValueError(f'Expected {self.N} finite nonnegative precisions, including closure')
        return r

    def filter(self,rho):
        r=self._rho(rho);F=self.F;Q=self.Q;n=self.n
        def sweep(S,details=False):
            minus=[];plus=[];updates=[]
            for v in r:
                d=S[:,0];U=np.eye(n);U[:,0]-=v*d/(1+v*S[0,0])
                post=sym(S-v*np.outer(d,d)/(1+v*S[0,0]))
                if details:minus.append(S);plus.append(post);updates.append(U)
                S=sym(F@post@F.T+Q)
            if details:return S,np.array(minus),np.array(plus),np.array(updates)
            return S
        S=self.stationary.copy()
        for _ in range(10):
            next_S=sweep(S)
            if np.max(abs(next_S-S)) < 2e-13:
                S=next_S;break
            S=next_S
        if np.max(abs(sweep(S)-S)) > 2e-12:
            S=symmetric_root(sweep,S)
        end,minus,plus,U=sweep(S,True)
        if min(np.linalg.eigvalsh(plus).ravel()) <= 0:
            raise ArithmeticError('Periodic posterior covariance is not positive')
        A=np.einsum('ij,kjl->kil',F,U)
        cycle=np.eye(n)
        for stage in A:cycle=stage@cycle
        if max(abs(np.linalg.eigvals(cycle))) >= 1:
            raise ArithmeticError('Periodic estimation error is unstable')
        return dict(minus=minus,plus=plus,U=U,A=A,
                    residual=float(np.max(abs(end-S))),cycle=cycle)

    def evaluate(self,rho,price=None):
        r=self._rho(rho);c=self.p.price if price is None else float(price)
        orbit=self.filter(r);U=orbit['U'];A=orbit['A'];n=self.n
        # Y_k is derivative of posterior loss with respect to the stage-k prior.
        forcing=np.zeros((n,n));back_product=np.eye(n)
        for k in range(self.N-1,-1,-1):
            forcing=U[k].T@self.W[k]@U[k]+A[k].T@forcing@A[k]
            back_product=back_product@A[k]
        first=solve_discrete_lyapunov(back_product.T,forcing)
        Y=first.copy();marginal=np.empty(self.N);relevance=np.empty_like(self.W)
        for k in range(self.N-1,-1,-1):
            V=self.W[k]+self.F.T@Y@self.F
            d=orbit['plus'][k,:,0]
            marginal[k]=d@V@d;relevance[k]=V
            Y=U[k].T@V@U[k]
        loss=float(np.einsum('kij,kji->',self.W,orbit['plus']))
        mech=self.full_information_work-loss;cost=c*float(sum(r))
        return dict(rho=r.copy(),J_net=mech-cost,J_mech=mech,C_sens=cost,
                    J_full=self.full_information_work,loss=loss,gradient=c-marginal,
                    marginal=marginal,relevance=relevance,orbit=orbit,
                    adjoint_residual=float(np.max(abs(first-Y))))

    def temporal(self,rho,cycles=25):
        """Positive lag series, with cross-cycle tail checked against the adjoint."""
        o=self.evaluate(rho);U=o['orbit']['U'];rows=[]
        for k in range(self.N):
            v=o['orbit']['plus'][k,:,0].copy();parts=np.zeros(3)
            for lag in range(cycles*self.N):
                j=(k+lag)%self.N
                if lag:v=U[j]@self.F@v
                part=0 if lag==0 else (1 if k+lag<self.N else 2)
                parts[part]+=v@self.W[j]@v
            M=o['marginal'][k]
            rows.append(dict(k=k+1,phase=(k+1)/self.N,rho=float(rho[k]),M=float(M),
                             immediate=parts[0],intra=parts[1],cross=parts[2],
                             series_error=abs(sum(parts)-M),
                             f_immediate=parts[0]/M,f_intra=parts[1]/M,f_cross=parts[2]/M))
        return rows
