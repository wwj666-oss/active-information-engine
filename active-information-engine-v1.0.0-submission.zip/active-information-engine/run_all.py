"""One entry point. Quick by default; --full recomputes both full maps."""
from pathlib import Path
import argparse,os,subprocess,sys
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR=str(root/'.mpl-cache'),PYTHONPATH=str(root/'src'))
def run(*args):subprocess.run([sys.executable,*args],cwd=root,env=env,check=True)
run('-m','unittest','discover','-s','tests','-v');run('scripts/validate_sm.py')
for script in ['reproduce_fig2.py','reproduce_fig3.py']:
    args=['scripts/'+script,'--workers',str(a.workers)]
    if a.full:args.append('--full')
    run(*args)
run('scripts/plot_figures.py','--mode','full' if a.full else 'quick')
run('scripts/audit_outputs.py','--mode','full' if a.full else 'quick')
