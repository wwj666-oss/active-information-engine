from pathlib import Path
import sys,json,csv,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

def native(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)

def save_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,default=native,allow_nan=False)+'\n');tmp.replace(path)

def save_csv(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    tmp.replace(path)

def manuscript_metadata():
    """Return the manuscript identifiers used for the supplied calculations."""
    manifest = json.loads((ROOT / 'docs' / 'manuscript.json').read_text())
    for entry in manifest['baseline']:
        digest = entry['sha256']
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid manuscript SHA-256 identifier')
    return manifest


def scalar_result(o):
    return {k:v for k,v in o.items() if k not in ['orbit','relevance','gradient','marginal','rho']}
