"""Optional finite-persistence evidence for SM VIII; not proof of either limit."""
from common import *
from active_engine import Parameters,Engine,solve

if __name__=='__main__':
    manuscript_metadata();passive=solve(Engine(Parameters(passive=True,Da=0)),polish=True)
    rows=[]
    for tau in [1e-5,1e-4,1e3,1e4,1e5]:
        e=Engine(Parameters(tau=tau,Da=4*tau));o=solve(e,starts=[passive['rho']],polish=True)
        rows.append(dict(tau=tau,J_net=o['J_net'],passive_net=passive['J_net'],
                         difference=o['J_net']-passive['J_net'],kkt=o['kkt'],
                         kalman_residual=o['orbit']['residual'],rho_N=float(o['rho'][-1])))
    assert abs(rows[0]['difference'])<abs(rows[1]['difference'])
    assert abs(rows[4]['difference'])<abs(rows[3]['difference'])<abs(rows[2]['difference'])
    save_csv(ROOT/'data/passive_limit_checks.csv',rows)
    save_json(ROOT/'reports/passive_limits.json',dict(rows=rows,passed=True,
              scope='Finite-parameter convergence evidence only; tau=100 is not the infinite-persistence limit.'))
    print('PASS: finite-parameter passive-limit trend')
