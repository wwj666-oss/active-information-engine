"""Recompute and check SM IX B-D. No archived numerical arrays are loaded."""
from common import *
from active_engine import Parameters,Engine,solve,activation,persistence_peak
from active_engine.validate import diagnostics
from dataclasses import replace
import platform,time

def main():
    manuscript_metadata();start=time.time();checks=[]
    def check(name,actual,target,tolerance):
        checks.append(dict(check=name,computed=float(actual),paper=float(target),
                           absolute_error=abs(float(actual)-target),tolerance=tolerance,
                           passed=abs(float(actual)-target)<=tolerance))
    e=Engine(Parameters());active=solve(e,polish=True)
    passive=solve(Engine(Parameters(passive=True,Da=0)),polish=True)
    detail=diagnostics(e,active)
    for name,target in [('J_net',2.229314),('J_mech',2.971665),('C_sens',.742350)]:
        check('IX B active '+name,active[name],target,5.1e-7)
    check('IX B passive J_net',passive['J_net'],.528038,5.1e-7)
    check('IX B rho_N',active['rho'][-1],0.,1e-7)
    check('IX B M_N_cross',active['marginal'][-1],.0874645,5.1e-8)
    print('IX B',scalar_result(active),detail,flush=True)
    threshold=activation();check('IX C c_cross',threshold['c_cross'],1.08146e-3,5.1e-9)
    activation_sides=[]
    for factor in [.95,1.05]:
        price=threshold['c_cross']*factor
        o=solve(e,price=price,polish=True)
        activation_sides.append(dict(price_over_cross=factor,rho_N=o['rho'][-1],kkt=o['kkt']))
    if activation_sides[0]['rho_N']<=1e-7 or activation_sides[1]['rho_N']>1e-7:
        raise AssertionError('Activation signs failed')
    print('IX C activation',threshold,flush=True)
    peak=persistence_peak();check('IX C peak tau',peak['tau_star'],1.1283,5.1e-5)
    check('IX C peak net work',peak['J_net'],2.48568,5.1e-6)
    check('IX C peak rho_N',peak['rho_N'],0.,1e-7)
    low=Engine(replace(e.p,price=.001));low_o=solve(low,polish=True)
    temporal=low.temporal(low_o['rho'])
    check('IX D rho_N',low_o['rho'][-1],.04050,5.1e-6)
    transfer=[]
    rng=np.random.default_rng(20261119)
    for price in [.00001,.001,.1]:
        p=Engine(Parameters(price=price,passive=True,Da=0))
        for i in range(4):
            r=rng.uniform(0,3,p.N);t=r.copy();t[0]+=t[-1];t[-1]=0
            a=p.evaluate(r);b=p.evaluate(t)
            transfer.append(dict(price=price,case=i,mechanical_gain=b['J_mech']-a['J_mech'],cost_error=b['C_sens']-a['C_sens']))
    if min(q['mechanical_gain'] for q in transfer)<-1e-11:raise AssertionError('Passive transfer failed')
    save_csv(ROOT/'data/sm_ix_b_d.csv',checks)
    save_csv(ROOT/'data/benchmark_schedule_active.csv',[dict(k=i+1,rho=r,M=active['marginal'][i],gradient=active['gradient'][i]) for i,r in enumerate(active['rho'])])
    save_csv(ROOT/'data/benchmark_schedule_passive.csv',[dict(k=i+1,rho=r) for i,r in enumerate(passive['rho'])])
    save_csv(ROOT/'data/fig2_temporal.csv',temporal)
    save_csv(ROOT/'data/passive_transfer.csv',transfer)
    save_csv(ROOT/'data/activation_sides.csv',activation_sides)
    save_json(ROOT/'reports/sm_validation.json',dict(python=platform.python_version(),numpy=np.__version__,
              active=scalar_result(active),passive=scalar_result(passive),diagnostics=detail,
              threshold=threshold,peak=peak,checks=checks,elapsed_seconds=time.time()-start,
              temporal_series_max_error=max(t['series_error'] for t in temporal),
              temporal_minimum_component=min(min(t['immediate'],t['intra'],t['cross']) for t in temporal)))
    assert all(c['passed'] for c in checks),[c for c in checks if not c['passed']]
    assert detail['work_absolute_error']<1e-10
    assert detail['full_information_absolute_error']<1e-10
    assert detail['finite_difference_max_error']<2e-7
    assert detail['forward_sensitivity_max_error']<1e-10
    assert detail['curvature_min']>=detail['curvature_lower_bound']-1e-10
    assert max(t['series_error'] for t in temporal)<1e-10
    print('PASS: SM IX B-D values and independent checks',flush=True)

if __name__=='__main__':main()
