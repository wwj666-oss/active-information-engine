"""Build a source archive and checksum manifest from the repository files."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'.git', '.venv', '.mpl-cache', '__pycache__', 'build', 'dist'}


def include(path):
    relative = path.relative_to(ROOT)
    if EXCLUDED.intersection(relative.parts):
        return False
    if any(part.endswith('.egg-info') for part in relative.parts):
        return False
    if path.name in {'SHA256SUMS', '.DS_Store'} or path.suffix in {'.pyc', '.log', '.tmp'}:
        return False
    if len(relative.parts) > 1 and relative.parts[:2] in {('data', 'quick'), ('figures', 'quick')}:
        return False
    if relative.parts[0] == 'reports' and path.name.endswith('_quick.json'):
        return False
    return True


def main():
    files = sorted(path for path in ROOT.rglob('*') if path.is_file() and include(path))
    manifest = ROOT / 'SHA256SUMS'
    manifest.write_text(''.join(
        hashlib.sha256(path.read_bytes()).hexdigest() + '  '
        + path.relative_to(ROOT).as_posix() + '\n' for path in files
    ))
    destination = ROOT / 'dist' / 'active-information-engine.zip'
    destination.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files + [manifest]:
            archive.write(path, Path('active-information-engine') / path.relative_to(ROOT))
    print(destination)
    print(f'{len(files) + 1} files; {destination.stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
