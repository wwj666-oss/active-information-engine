"""Render computed CSVs only. No numerical model is evaluated here."""
from common import *
import os
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,Normalize
from matplotlib.patches import Patch
import argparse

BLUE='#38568d';PEACH='#f2d4b0';CURRENT='#d7e4f3';CROSS='#8795b7'

def read(path):return np.atleast_1d(np.genfromtxt(path,names=True,delimiter=','))

def panel(ax,label):ax.text(-.14,1.04,label,transform=ax.transAxes,fontweight='bold',va='bottom')

def finish(fig,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    for ext in ['png','svg','pdf']:fig.savefig(path.with_suffix('.'+ext),dpi=230,bbox_inches='tight')
    plt.close(fig)

def fig2(folder,out):
    temporal=read(folder/'fig2_temporal.csv');data=read(folder/'fig2_map.csv');boundary=read(folder/'fig2_boundary.csv')
    fig=plt.figure(figsize=(8.4,3.35),layout='constrained')
    grid=fig.add_gridspec(2,2,width_ratios=[1,1.15],height_ratios=[.75,1.])
    ax=fig.add_subplot(grid[0,0]);bottom=fig.add_subplot(grid[1,0],sharex=ax);right=fig.add_subplot(grid[:,1])
    k=temporal['k'];ax.plot(k,temporal['rho'],color=BLUE,lw=1.4,marker='.',ms=2)
    ax.set_ylabel(r'$\rho_k^\star$');ax.set_xlim(1,50);ax.set_ylim(bottom=0);ax.tick_params(labelbottom=False)
    ax.text(.98,.8,r'$\rho_N^\star = %.5f$'%temporal['rho'][-1],transform=ax.transAxes,ha='right',fontsize=9)
    M=.001
    bottom.stackplot(k,temporal['immediate']/M,temporal['intra']/M,temporal['cross']/M,
                     colors=[CURRENT,PEACH,CROSS],labels=['Current','Later in cycle','Future cycles'])
    bottom.axhline(1,color='#777777',ls='--',lw=.7)
    bottom.set(xlabel=r'measurement stage $k$',ylabel=r'$M_k/c$',ylim=(0,1.06))
    ax.legend(handles=[Patch(color=c,label=l) for c,l in zip([CURRENT,PEACH,CROSS],['Current','Later in cycle','Future cycles'])],
              loc='lower left',bbox_to_anchor=(0.,1.01),frameon=False,fontsize=7.2,ncol=3,
              columnspacing=.7,handlelength=1.1,handletextpad=.3)
    ts=np.unique(data['tau']);cs=np.unique(data['price'])
    values=np.array([[data[(data['tau']==t)&(data['price']==c)]['rho_N'][0] for t in ts] for c in cs])
    cmap=LinearSegmentedColormap.from_list('precision',['#ffffff','#c4d9ed',BLUE])
    mesh=right.pcolormesh(ts,cs,values,shading='nearest',cmap=cmap,rasterized=True)
    right.plot(boundary['tau'],boundary['c_cross'],color=BLUE,lw=1.7)
    right.set(xscale='log',yscale='log',xlabel=r'persistence $\tau_a/\tau_r$',ylabel=r'sensing price $c$')
    right.set_xlim(ts[0],ts[-1]);right.set_ylim(cs[0],cs[-1]);fig.colorbar(mesh,ax=right,label=r'$\rho_N^\star$',pad=.02)
    right.text(.98,.96,r'Passive: $\rho_N^\star=0$',transform=right.transAxes,ha='right',va='top',fontsize=8,color='#666666')
    panel(ax,'(a)');panel(right,'(b)');finish(fig,out/'fig2_temporal_value')

def fig3(folder,out):
    data=read(folder/'fig3_map.csv');slice_=read(folder/'fig3_slice.csv');ridge=read(folder/'fig3_ridge.csv')
    roots=read(folder/'fig3_zero_gain.csv')
    fig,(left,right)=plt.subplots(1,2,figsize=(8.4,3.2),layout='constrained',gridspec_kw=dict(width_ratios=[1,1.15]))
    tau=slice_['tau'];net=slice_['J_net'];mech=slice_['J_mech']
    left.fill_between(tau,net,mech,color='#f7e2d7',label='Sensing cost')
    left.plot(tau,mech,color='#dd6650',ls='-.',label='Mechanical',lw=1.6)
    left.plot(tau,net,color=BLUE,label='Net',lw=1.8)
    left.axhline(slice_['passive_mech'][0],color='#999999',ls=':',lw=1.2)
    left.axhline(slice_['passive_net'][0],color='#999999',ls='--',lw=1.2)
    peak=ridge[ridge['N']==50][0];left.plot(peak['tau_star'],peak['J_net'],'o',mfc='white',mec=BLUE,ms=4)
    left.annotate(r'$\tau_a^\star/\tau_r\simeq%.2f$'%peak['tau_star'],
                  (peak['tau_star'],peak['J_net']),xytext=(12,4),textcoords='offset points',fontsize=8)
    left.set(xscale='log',xlabel=r'persistence $\tau_a/\tau_r$',ylabel='work per cycle',xlim=(tau[0],tau[-1]))
    left.legend(frameon=False,loc='upper left',fontsize=8)
    left.text(.48,slice_['passive_mech'][0]+.04,'Passive mech.',transform=left.get_yaxis_transform(),fontsize=7,color='#777777')
    left.text(.48,slice_['passive_net'][0]+.04,'Passive net',transform=left.get_yaxis_transform(),fontsize=7,color='#777777')
    ts=np.unique(data['tau']);times=np.unique(data['T'])
    z=np.array([[data[(data['tau']==t)&(data['T']==T)]['relative_gain'][0]*100 for T in times] for t in ts])
    vmin=min(-50.,float(z.min()));vmax=max(400.,float(z.max()))
    zero_position=-vmin/(vmax-vmin)
    cmap=LinearSegmentedColormap.from_list('gain',[(0.,'#d8947e'),(zero_position,'#f5f3ef'),(1.,'#365d8b')])
    norm=Normalize(vmin=vmin,vmax=vmax)
    mesh=right.pcolormesh(times,ts,z,cmap=cmap,norm=norm,shading='nearest',rasterized=True)
    right.plot(ridge['T'],ridge['tau_star'],color='#333333',lw=1.2,label=r'$\tau_a^\star(\mathcal{T})$')
    if len(roots):right.plot(roots['T'],roots['tau'],'--',color='#333333',lw=1.2,label=r'$\Delta J^\star=0$')
    right.axvline(5,color='white',lw=.7,alpha=.8)
    right.set(yscale='log',xlabel=r'cycle duration $\mathcal{T}/\tau_r$',ylabel=r'persistence $\tau_a/\tau_r$',
              xlim=(times[0],times[-1]),ylim=(ts[0],ts[-1]))
    right.legend(loc='lower right',frameon=False,fontsize=8)
    fig.colorbar(mesh,ax=right,label='relative net-work gain (%)',pad=.02)
    panel(left,'(a)');panel(right,'(b)');finish(fig,out/'fig3_energetic_consequences')

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['quick','full'],default='full');a=p.parse_args()
    manuscript_metadata()
    plt.rcParams.update({'font.family':'DejaVu Serif','mathtext.fontset':'stix','font.size':10,
                        'axes.labelsize':10,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.7})
    folder=ROOT/'data'/a.mode;out=ROOT/'figures'/a.mode
    fig2(folder,out);fig3(folder,out)
    print('Saved figures in',out)
if __name__=='__main__':main()
