"""Fresh Fig.2 optimizations. Full: 40x45 grid. Quick: 8x10 grid."""
from common import *
from active_engine import Parameters,Engine,solve,activation
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,time

def run_row(task):
    tau,prices,folder=task
    e=Engine(Parameters(tau=float(tau),Da=4*float(tau)))
    fw=[];bw=[];warm=None
    for c in prices:
        o=solve(e,price=float(c),starts=None if warm is None else [warm]);fw.append(o);warm=o['rho']
    warm=np.zeros(e.N)
    for c in prices[::-1]:
        o=solve(e,price=float(c),starts=[warm]);bw.append(o);warm=o['rho']
    bw=bw[::-1];rows=[];schedules=[]
    for c,a,b in zip(prices,fw,bw):
        o=a if a['J_net']>=b['J_net'] else b
        rows.append(dict(tau=tau,price=c,rho_N=float(o['rho'][-1]),J_net=o['J_net'],
                         J_mech=o['J_mech'],C_sens=o['C_sens'],kkt=o['kkt'],
                         bidirectional_net_gap=abs(a['J_net']-b['J_net'])))
        schedules.append(dict(tau=tau,price=c,rho=o['rho']))
    boundary=activation(float(tau))
    save_json(Path(folder)/f'tau_{tau:.12g}.json',dict(rows=rows,schedules=schedules,boundary=boundary))
    return rows,boundary

def main():
    p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    manuscript_metadata();mode='full' if a.full else 'quick';folder=ROOT/'data'/mode
    prices=np.geomspace(1e-5,2.2e-3,45 if a.full else 10)
    taus=np.geomspace(.05,3,40 if a.full else 8)
    out=folder/'fig2_rows';out.mkdir(parents=True,exist_ok=True)
    results=[];start=time.time()
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        futures=[pool.submit(run_row,(float(t),prices.tolist(),str(out))) for t in taus]
        for f in as_completed(futures):
            results.append(f.result());print('Fig2 rows',len(results),'/',len(taus),flush=True)
    results.sort(key=lambda x:x[1]['tau']);rows=[r for rs,_ in results for r in rs];bounds=[b for _,b in results]
    e=Engine(Parameters(price=.001));o=solve(e,polish=True)
    save_csv(folder/'fig2_temporal.csv',e.temporal(o['rho']))
    save_csv(folder/'fig2_map.csv',rows);save_csv(folder/'fig2_boundary.csv',bounds)
    mismatches=[]
    for rs,b in results:
        for r in rs:
            if (r['price']<b['c_cross'])!=(r['rho_N']>1e-7):mismatches.append(r)
    report=dict(mode=mode,grid_shape=[len(taus),len(prices)],cells=len(rows),
                max_kkt=max(r['kkt'] for r in rows),max_bidirectional_net_gap=max(r['bidirectional_net_gap'] for r in rows),
                max_boundary_relative_root_residual=max(b['relative_root_residual'] for b in bounds),
                activation_mismatches=mismatches,elapsed_seconds=time.time()-start,
                baseline=manuscript_metadata()['baseline'])
    save_json(ROOT/'reports'/f'fig2_{mode}.json',report)
    assert not mismatches
    assert report['max_bidirectional_net_gap']<1e-7
    print('Fig2 scan PASS',report['cells'],flush=True)

if __name__=='__main__':main()
