"""Fresh Fig.3 scans, passive references, continuous ridges and zero-gain roots."""
from common import *
from active_engine import Parameters,Engine,solve,persistence_peak
from active_engine.validate import direct_work
from concurrent.futures import ProcessPoolExecutor,as_completed
from scipy.optimize import brentq
import argparse,time

def run_row(task):
    N,taus,folder=task;T=N*.1
    passive=solve(Engine(Parameters(N=N,passive=True,Da=0)))
    fw=[];bw=[];models=[];warm=passive['rho'];cache={}
    for tau in taus:
        e=Engine(Parameters(N=N,tau=float(tau),Da=4*float(tau)));models.append(e)
        o=solve(e,starts=[warm]);fw.append(o);warm=o['rho']
    warm=np.full(N,.15)
    for e in models[::-1]:
        o=solve(e,starts=[warm]);bw.append(o);warm=o['rho']
    bw=bw[::-1];rows=[];schedules=[]
    for tau,e,a,b in zip(taus,models,fw,bw):
        o=a if a['J_net']>=b['J_net'] else b;cache[float(tau)]=o
        work=direct_work(e,o['rho'])
        rows.append(dict(N=N,T=T,tau=tau,J_net=o['J_net'],J_mech=o['J_mech'],C_sens=o['C_sens'],
                         passive_net=passive['J_net'],passive_mech=passive['J_mech'],
                         relative_gain=o['J_net']/passive['J_net']-1.,
                         rho_N=float(o['rho'][-1]),kkt=o['kkt'],
                         bidirectional_net_gap=abs(a['J_net']-b['J_net']),
                         work_error=abs(work['work']-o['J_mech']),cycle_radius=work['cycle_radius']))
        schedules.append(dict(tau=tau,rho=o['rho']))
    peak=persistence_peak(N);peak['passive_net']=passive['J_net']
    def net_gain(logtau):
        tau=float(np.exp(logtau))
        if tau not in cache:
            nearest=min(cache,key=lambda t:abs(np.log(t/tau)))
            cache[tau]=solve(Engine(Parameters(N=N,tau=tau,Da=4*tau)),starts=[cache[nearest]['rho']])
        return cache[tau]['J_net']-passive['J_net']
    roots=[]
    for a,b in zip(rows[:-1],rows[1:]):
        if a['relative_gain']*b['relative_gain']<0:
            x=brentq(net_gain,np.log(a['tau']),np.log(b['tau']),xtol=2e-8)
            roots.append(dict(N=N,T=T,tau=float(np.exp(x)),net_gain_residual=net_gain(x)))
    save_json(Path(folder)/f'N{N:03d}.json',dict(rows=rows,schedules=schedules,peak=peak,roots=roots,
              passive=scalar_result(passive),passive_schedule=passive['rho']))
    return rows,peak,roots

def main():
    p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    manuscript_metadata();mode='full' if a.full else 'quick';folder=ROOT/'data'/mode
    taus=np.geomspace(.01,100,81 if a.full else 17)
    Ns=list(range(20,101,2)) if a.full else [20,30,40,50,60,80,100]
    out=folder/'fig3_rows';out.mkdir(parents=True,exist_ok=True)
    results=[];start=time.time()
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        futures=[pool.submit(run_row,(N,taus.tolist(),str(out))) for N in Ns]
        for f in as_completed(futures):
            results.append(f.result());print('Fig3 rows',len(results),'/',len(Ns),flush=True)
    results.sort(key=lambda x:x[1]['N']);rows=[r for rs,_,_ in results for r in rs]
    save_csv(folder/'fig3_map.csv',rows)
    save_csv(folder/'fig3_slice.csv',[r for r in rows if r['N']==50])
    save_csv(folder/'fig3_ridge.csv',[peak for _,peak,_ in results])
    roots=[r for _,_,rs in results for r in rs]
    if roots:save_csv(folder/'fig3_zero_gain.csv',roots)
    else:(folder/'fig3_zero_gain.csv').write_text('N,T,tau,net_gain_residual\n')
    report=dict(mode=mode,grid_shape=[len(Ns),len(taus)],cells=len(rows),
              max_kkt=max(r['kkt'] for r in rows),max_work_error=max(r['work_error'] for r in rows),
              max_bidirectional_net_gap=max(r['bidirectional_net_gap'] for r in rows),
              ridge_tau_min=min(peak['tau_star'] for _,peak,_ in results),
              ridge_tau_max=max(peak['tau_star'] for _,peak,_ in results),
              elapsed_seconds=time.time()-start,baseline=manuscript_metadata()['baseline'])
    save_json(ROOT/'reports'/f'fig3_{mode}.json',report)
    assert report['max_work_error']<1e-9
    assert report['max_bidirectional_net_gap']<1e-7
    print('Fig3 scan PASS',report['cells'],flush=True)

if __name__=='__main__':main()
