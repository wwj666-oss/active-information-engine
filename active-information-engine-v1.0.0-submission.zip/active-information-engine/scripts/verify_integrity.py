"""Check the distributed files against SHA256SUMS (standard library only)."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
checks=(root/'SHA256SUMS').read_text().splitlines()
for line in checks:
    expected,name=line.split('  ',1)
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if actual!=expected:raise SystemExit('CHANGED OR CORRUPT: '+name)
print('PASS:',len(checks),'file checksums')
