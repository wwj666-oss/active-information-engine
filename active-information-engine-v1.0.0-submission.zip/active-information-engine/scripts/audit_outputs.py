"""Audit saved schedules and CSVs by fresh evaluation; fail on missing or corrupt data."""
from common import *
from active_engine import Parameters,Engine,kkt
from active_engine.validate import direct_work
import argparse

def check_csv(path, rows):
    """Check every plotted field against its independently audited JSON source."""
    with Path(path).open(newline='') as stream:
        reader = csv.DictReader(stream)
        actual = list(reader)
        fields = reader.fieldnames
    assert len(actual) == len(rows), f'CSV row count mismatch: {path.name}'
    if rows:
        assert set(fields) == set(rows[0]), f'CSV schema mismatch: {path.name}'
    for index, (saved, expected) in enumerate(zip(actual, rows)):
        for key, value in expected.items():
            value = float(value)
            observed = float(saved[key])
            assert np.isfinite(observed) and np.isclose(observed, value, rtol=1e-12, atol=1e-12), (path.name, index, key)

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['quick','full'],default='full');a=p.parse_args()
    manuscript_metadata();folder=ROOT/'data'/a.mode
    records=[];work_errors=[];certificates=[]
    fig2_rows=[];fig3_rows=[];boundaries=[];peaks=[];roots=[]
    for path in sorted((folder/'fig2_rows').glob('*.json')):
        saved=json.loads(path.read_text());tau=saved['rows'][0]['tau'];e=Engine(Parameters(tau=tau,Da=4*tau))
        assert len(saved['rows'])==len(saved['schedules'])==(45 if a.mode=='full' else 10)
        fig2_rows.extend(saved['rows']);boundaries.append(saved['boundary'])
        for row,schedule in zip(saved['rows'],saved['schedules']):
            assert row['tau']==schedule['tau']==tau and row['price']==schedule['price']
            c=row['price'];o=e.evaluate(schedule['rho'],c)
            assert abs(o['rho'][-1]-row['rho_N'])<1e-12
            assert (c<saved['boundary']['c_cross'])==(o['rho'][-1]>1e-7)
            for name in ['J_net','J_mech','C_sens']:
                records.append(abs(o[name]-row[name]))
            assert kkt(o['rho'],o['gradient'])<=max(2e-8,c*2e-5)
            g=-o['gradient'];budget=e.full_information_work/c
            certificates.append(max(0.,max(0.,float(max(g)))*budget-float(g@o['rho'])))
        for i in [0,len(saved['rows'])//2,len(saved['rows'])-1]:
            o=e.evaluate(saved['schedules'][i]['rho']);d=direct_work(e,o['rho'])
            work_errors.append(abs(d['work']-o['J_mech']))
    fig3_count=0
    for path in sorted((folder/'fig3_rows').glob('*.json')):
        saved=json.loads(path.read_text())
        assert len(saved['rows'])==len(saved['schedules'])==(81 if a.mode=='full' else 17)
        fig3_rows.extend(saved['rows']);peaks.append(saved['peak']);roots.extend(saved['roots'])
        N=saved['rows'][0]['N'];p=Engine(Parameters(N=N,passive=True,Da=0))
        po=p.evaluate(saved['passive_schedule'])
        assert abs(po['J_net']-saved['passive']['J_net'])<1e-11
        assert kkt(po['rho'],po['gradient'])<2e-6
        for row,schedule in zip(saved['rows'],saved['schedules']):
            assert row['N']==N and row['tau']==schedule['tau'] and row['T']==N*.1
            tau=row['tau'];e=Engine(Parameters(N=N,tau=tau,Da=4*tau));o=e.evaluate(schedule['rho'])
            assert abs(o['rho'][-1]-row['rho_N'])<1e-12
            assert abs(po['J_net']-row['passive_net'])<1e-11
            assert abs(po['J_mech']-row['passive_mech'])<1e-11
            assert abs(o['J_net']/po['J_net']-1-row['relative_gain'])<1e-11
            for name in ['J_net','J_mech','C_sens']:records.append(abs(o[name]-row[name]))
            assert kkt(o['rho'],o['gradient'])<=2e-6
            g=-o['gradient'];budget=e.full_information_work/e.p.price
            certificates.append(max(0.,max(0.,float(max(g)))*budget-float(g@o['rho'])))
            fig3_count+=1
        assert saved['peak']['J_net']>=max(r['J_net'] for r in saved['rows'])-1e-7
    assert records and max(records)<1e-11
    assert max(work_errors)<1e-9
    fig2=np.atleast_1d(np.genfromtxt(folder/'fig2_map.csv',names=True,delimiter=','))
    fig3=np.atleast_1d(np.genfromtxt(folder/'fig3_map.csv',names=True,delimiter=','))
    assert len(fig2)==(1800 if a.mode=='full' else 80)
    assert len(fig3)==(3321 if a.mode=='full' else 119)
    assert len(fig2_rows)==len(fig2) and len(fig3_rows)==len(fig3)
    assert len(boundaries)==(40 if a.mode=='full' else 8)
    assert len(peaks)==(41 if a.mode=='full' else 7)
    assert len({(r['tau'],r['price']) for r in fig2_rows})==len(fig2_rows)
    assert len({(r['N'],r['tau']) for r in fig3_rows})==len(fig3_rows)
    fig2_rows.sort(key=lambda r:(r['tau'],r['price']))
    fig3_rows.sort(key=lambda r:(r['N'],r['tau']))
    boundaries.sort(key=lambda r:r['tau']);peaks.sort(key=lambda r:r['N'])
    roots.sort(key=lambda r:(r['N'],r['tau']))
    check_csv(folder/'fig2_map.csv',fig2_rows)
    check_csv(folder/'fig2_boundary.csv',boundaries)
    check_csv(folder/'fig3_map.csv',fig3_rows)
    check_csv(folder/'fig3_slice.csv',[r for r in fig3_rows if r['N']==50])
    check_csv(folder/'fig3_ridge.csv',peaks)
    check_csv(folder/'fig3_zero_gain.csv',roots)
    temporal_engine=Engine(Parameters(price=.001))
    # Fig. 2 uses c=.001 rather than the c=.1 benchmark schedule.
    from active_engine import solve
    check_csv(folder/'fig2_temporal.csv',temporal_engine.temporal(solve(temporal_engine,polish=True)['rho']))
    for arr in [fig2,fig3]:
        for col in arr.dtype.names:assert np.isfinite(arr[col]).all()
        assert max(abs(arr['J_net']-arr['J_mech']+arr['C_sens']))<1e-11
    for stem in ['fig2_temporal_value','fig3_energetic_consequences']:
        for suffix in ['png','svg','pdf']:
            assert (ROOT/'figures'/a.mode/(stem+'.'+suffix)).stat().st_size>1000
    report=dict(mode=a.mode,recomputed_fig2_schedules=len(fig2),recomputed_fig3_schedules=fig3_count,
                max_saved_objective_error=max(records),independent_fig2_work_checks=len(work_errors),
                max_independent_fig2_work_error=max(work_errors),
                max_concavity_global_gap_upper_bound=max(certificates),
                manuscript_metadata='recorded',plotted_csv_fields_checked=True,all_passed=True)
    save_json(ROOT/'reports'/f'audit_{a.mode}.json',report)
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
