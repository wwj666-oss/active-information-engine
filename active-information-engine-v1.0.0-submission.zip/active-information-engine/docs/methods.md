# Numerical methods

## Equations and implementation

Equation numbers refer to the v4 Supplemental Material. The source PDF hashes are recorded in `manuscript.json`.

| SM reference | Calculation | Implementation |
|---|---|---|
| I, S1-S4 | Exact discrete dynamics and process covariance | `model.matrices` |
| I A, S5-S8 | Kalman update and periodic covariance | `model.kalman_update`, `Engine.filter` |
| II B-C, S11-S12 | Periodic Riccati equation and feedback gains | `Engine._control` |
| III B-C, S14-S17 | Full-information work and estimation loss | `Engine.evaluate` |
| IV C-D, S22-S24 | Cyclic adjoint and marginal sensing value | `Engine.evaluate` |
| V, S25-S28 | Immediate, intra-cycle, and cross-cycle value | `Engine.temporal` |
| VI B, S31-S32; IX B, S49 | Precision optimization and KKT residual | `optimize.solve`, `optimize.kkt` |
| VI C-D | Passive reference and boundary transfer | `Parameters(passive=True)`, tests |
| VII B, S39-S40 | Closing-stage activation threshold | `optimize.activation` |
| IX B-D | Benchmarks and figure parameters | `scripts/validate_sm.py`, figure scripts |

Python index `0` corresponds to stage `k = 1`; index `N - 1` is the closing stage. Sensing occurs at `(k - 1) * dt`. The filter propagates through the final holding interval without a reset.

## Periodic control and filtering

The mechanical Riccati equation is initialized by iteration and refined by a symmetric-matrix root solve. The solution is checked for positive action curvature and a stable closed-loop cycle matrix.

The Kalman covariance follows the same iteration-and-root procedure. Posterior covariance positivity and estimation-error stability are checked explicitly. At zero precision the update is the identity; no measurement is constructed.

The code uses a prior-loss adjoint `Y`, related to the manuscript's posterior-relevance matrix `V` by

```text
V_k = W_k + F.T @ Y_{k+1} @ F
Y_k = U_k.T @ V_k @ U_k
M_k = d_k.T @ V_k @ d_k
```

Here `d_k` is the first column of the posterior covariance. The cyclic adjoint is solved with a discrete Lyapunov equation.

## Sensing optimization

All numerical scans use the linear cost `c * sum(rho)`. L-BFGS-B minimizes the mechanical loss plus sensing cost over all `N` nonnegative precisions. The scaled variable `q = sqrt(c) * rho` improves conditioning at low prices. Positive variables are polished by a stationary-point solve when needed.

The KKT residual uses the SM activity threshold `rho > 1e-7`. A solution is accepted when the residual is at most `max(2e-8, 2e-5 * c)` in the original units. Optimizer termination and KKT acceptance are recorded separately. Joint concavity supplies the global optimality criterion for precision allocation; multiple starts and bidirectional continuation check numerical consistency.

A conservative objective-gap bound follows from `J(0) = 0`, `J_mech <= J_FO`, and concavity. With `g = M - c`,

```text
J* - J(rho) <= max(0, max(g)) * J_FO / c - g @ rho.
```

The output audit reports the largest such bound across the supplied grids.

## Independent checks

Mechanical work is also evaluated from the stationary joint covariance of the physical state, estimated state, and trap center. A discrete Lyapunov equation closes the covariance orbit, and the work is computed from potential-energy changes at each displacement. This calculation does not use the reduced-work formula or the adjoint.

Full-information work is checked separately by propagating the physical state under full-state feedback. The cyclic gradient is compared with both forward covariance sensitivities and componentwise finite differences. The discrete process covariance is checked against the Van Loan integral construction.

## Scan domains

| Calculation | Parameters |
|---|---|
| Fig. 2(a) | `N = 50`, `tau = 0.5`, `c = 0.001` |
| Fig. 2(b) | 40 logarithmic persistence values from 0.05 to 3; 45 logarithmic prices from 1e-5 to 2.2e-3 |
| Fig. 3(a) | `N = 50`, `c = 0.1`; 81 logarithmic persistence values from 0.01 to 100 |
| Fig. 3(b) | `N = 20, 22, ..., 100`, with the same persistence grid and price |

All scans use `dt = 0.1` and `Da = 4 * tau`. The activation boundary is found by reoptimizing the face `rho_N = 0` and solving `M_N - c = 0`.

For each duration, the persistence peak is refined over `0.3 <= tau <= 3`. The audit checks that the refined value is no smaller than the maximum on the wider figure grid. This scalar search is distinct from the global precision optimization. It does not prove uniqueness of the persistence optimum outside the scanned domain.

Plots use the computed cells without smoothing. Lines connect computed boundary and ridge points. The net-gain color scale is linear, with a neutral color at zero. The grid dimensions are repository choices; the manuscript does not specify a pixel-exact plotting recipe.
