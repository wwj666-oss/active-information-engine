# Validation

Results for the supplied full scans. The code uses NumPy 1.24.3, SciPy 1.11.1, and Matplotlib 3.7.2. Python 3.11 is recommended.

## SM IX B-D

All 11 comparisons pass at the precision reported in the supplement.

| Quantity | SM value | Computed value |
|---|---:|---:|
| IX B active J_net | 2.229314 | 2.229314356 |
| IX B active J_mech | 2.971665 | 2.9716646464 |
| IX B active C_sens | 0.74235 | 0.742350290406 |
| IX B passive J_net | 0.528038 | 0.528038046012 |
| IX B rho_N | 0 | 0 |
| IX B M_N_cross | 0.0874645 | 0.0874644670175 |
| IX C c_cross | 0.00108146 | 0.00108145659425 |
| IX C peak tau | 1.1283 | 1.12827718173 |
| IX C peak net work | 2.48568 | 2.48568238547 |
| IX C peak rho_N | 0 | 0 |
| IX D rho_N | 0.0405 | 0.0405023737832 |

## Independent checks

| Check | Maximum absolute error |
|---|---:|
| Reduced versus direct work | 8.44e-15 |
| Full-information work | 7.11e-15 |
| Finite-difference gradient | 1.76e-10 |
| Forward-sensitivity gradient | 8.33e-17 |

## Full scans

| Scan | Points | Maximum KKT residual | Maximum bidirectional net-work difference |
|---|---:|---:|---:|
| Fig. 2 | 1800 | 1.03e-09 | 2.49e-14 |
| Fig. 3 | 3321 | 6.33e-08 | 1.07e-13 |

The maximum direct-work discrepancy across Fig. 3 is 4.96e-13. The persistence maximizing net work ranges from 0.897535 to 1.368679 over the 41 cycle durations.

Reevaluation of all 5,121 stored schedules reproduces the saved objective values with maximum discrepancy 0. An additional 120 Fig. 2 schedules were checked by direct work propagation; the maximum discrepancy is 4.62e-14.

The largest conservative objective-gap bound from concavity is 1.88e-05. This is an upper bound, not an observed work error.

The ten scientific regression tests and the coarse end-to-end pipeline pass. Machine-readable results are in `reports/`. The original full scans were computed before repository packaging; their values are retained unchanged. CI is configured to run the tests and SM benchmarks on Python 3.11.
