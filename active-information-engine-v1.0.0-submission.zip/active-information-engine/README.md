# Active Information Engine

Numerical code for *Optimal Net Work in an Active Information Engine with Costly Sensing*.

The code solves the periodic feedback and sensing problem for an active Ornstein-Uhlenbeck particle in a harmonic trap. It includes the passive reference, the scans for Figs. 2 and 3, and the numerical checks in Supplemental Material (SM) IX B-D.

## Installation

Use Python 3.11 with the pinned runtime and transitive dependencies:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Windows, activate the environment with `.venv\Scripts\activate`.

The portable version lock is `requirements-lock.txt`. The additional
`requirements-macos-arm64.lock` contains SHA-256 hashes of the official PyPI
wheels used for the clean CPython 3.11 / macOS arm64 acceptance run.
Use the portable lock on other platforms.

## Reproduce the results

Run the tests, benchmark checks, and a coarse scan:

```sh
python run_all.py --workers 4
```

For the full figure grids:

```sh
python run_all.py --full --workers 4
```

Use `--workers 1` to run the scans in a single process. The full calculation contains 1,800 Fig. 2 points and 3,321 Fig. 3 points. Each point requires a new joint precision optimization. The supplied full scans took about 2 and 6 minutes, respectively, with four worker processes; timings depend on the machine.

The full data and figures are included. To redraw them without repeating the optimization:

```sh
python scripts/plot_figures.py --mode full
```

The default coarse run writes to `data/quick/` and `figures/quick/`. The full run writes to `data/full/` and `figures/full/`.

## Validation

```sh
python scripts/validate_sm.py
python scripts/audit_outputs.py --mode full
python scripts/validate_limits.py
```

The tests cover the periodic filter, the control Riccati equation, the cyclic gradient, direct work evaluation, and passive boundary-sensing dominance. The benchmark check compares 11 quantities with SM IX B-D. The output audit reevaluates every saved precision schedule and checks the reported objectives.

See [validation results](docs/validation.md) for the numerical residuals and [methods](docs/methods.md) for the equation-to-code correspondence. The [data dictionary](data/README.md) describes the CSV and JSON fields.

## Model conventions

All figure calculations use `kBT = gamma = kappa = 1` and `dt = 0.1`. Persistence scans keep the active-force variance fixed at `Da / tau = 4`, so `Da = 4 * tau`.

A schedule contains `N` sensing precisions, including the closing stage. Only the first `N - 1` trap displacements are free. The final displacement returns the trap center to zero. The particle state and the filtering distribution continue across cycles. Zero precision means that no observation is taken.

Mechanical work and sensing expenditure are evaluated at the same net-work-optimal schedule. The passive reference is optimized separately at the same price and cycle duration.

## Repository layout

```text
src/active_engine/   Dynamics, periodic solvers, optimization, and validation
scripts/            Figure scans, benchmark checks, plotting, and output audit
tests/              Scientific regression tests
data/full/          Full scans and precision schedules
figures/full/       Figure 2 and Figure 3 in PDF, SVG, and PNG formats
reports/            Numerical validation records
docs/               Methods, manuscript identifiers, and validation summary
```

The implementation was checked against the v4 manuscript and supplement identified in [docs/manuscript.json](docs/manuscript.json). It was assembled from the manuscript equations with reference to earlier project solvers; it is not an archive of the original author code. Manuscript PDFs and historical working files are not included.

To build a source archive, run `python scripts/package.py`. To check an unchanged archive against its file manifest, run `python scripts/verify_integrity.py`. Recomputing results can change checksums.

No reuse license has been assigned. See [LICENSE](LICENSE).

## Submission acceptance

Version 1.0.0 is intended for the `v1.0.0-submission` tag. See
[acceptance report](docs/acceptance.md) for the input archive identifier, repairs,
clean-environment checks, manuscript comparisons, and limits of validation.
The public repository contains numerical code, generated data, and documentation.
Manuscript PDFs and historical drafts are excluded. No Zenodo deposit was made.
